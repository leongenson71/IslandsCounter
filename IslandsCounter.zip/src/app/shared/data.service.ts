import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  colsCnt: number;              //cols num
  rowsCnt: number;              //rows num

  constructor() { }
}
