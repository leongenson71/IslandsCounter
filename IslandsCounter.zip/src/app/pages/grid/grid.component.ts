import { Component, AfterViewChecked, ViewChild, ElementRef } from '@angular/core';
import { DataService } from 'src/app/shared/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements AfterViewChecked  {

  @ViewChild("canvasGrid",{static:false}) canvasGrid: ElementRef;

  cols: number = this.service.colsCnt;  //cols num
  rows: number = this.service.rowsCnt;  //rows num

  btnMessage: string = "SOLVE"; //msg on button
  filledTbl: boolean[][]  = []; //array for count islands
  numbTbl: number[][]  = [];    //array to save islands and color after that
  counter: number;              //islands counter
  isColorGrid: boolean = false; //wich grid to show

  constructor(
    private service: DataService,
    private router: Router) { }


  onClick() {
    if (!this.isColorGrid){
     this.btnMessage = "RESTART";
    }
    else{
      this.btnMessage = "SOLVE";
      this.router.navigate([''])
    }

    this.isColorGrid = !this.isColorGrid;
  }

  ngAfterViewChecked(){

    this.drawGrid();

    if (!this.isColorGrid){
      this.counter = this.countIslands();
   }
  }

  //draw grid
  drawGrid(): void{

    //colors  for islands
    enum Color {
      "red" = 1, "green", "blue", "brown", "orange",
      "yellow", "purple", "violet", "lightBlue","lightgreen"
    }

    //let cell size (normal = 20, if dimensions > 100 = 10)
    let cellSize = (this.cols > 100 && this.rows > 100) ? 10 : 20;

    //get canvas element
     let canv =  this.canvasGrid.nativeElement;
     let ctx = canv.getContext("2d");

    //size of canvas
    canv.width = this.cols * cellSize;
    canv.height = this.rows * cellSize ;

    ctx.strokeStyle = "black";
    ctx.fillStyle = "black";

    ctx.rect(0,0,  canv.width, canv.height);

    //draw rows
    for (let r = 0; r <= this.rows ; r++) {
      ctx.beginPath();
      ctx.moveTo(0, r * cellSize);
      ctx.lineTo(this.cols * cellSize , r * cellSize);
      ctx.stroke();
    }

    //draw cols
    for (let c = 0; c <= this.cols ; c++) {
      ctx.beginPath();
      ctx.moveTo(c * cellSize, 0);
      ctx.lineTo(c * cellSize, this.rows * cellSize);
      ctx.stroke();
    }

    if (!this.isColorGrid)
    {
      //fill cells randomaly with black color
      for (let r = 0; r < this.rows  ; r++) {
        this.filledTbl[r]=[];
        this.numbTbl[r]=[];
        for (let c = 0; c < this.cols ; c++) {
          this.numbTbl[r][c] = 0;
          if (Math.ceil( Math.random() * 10) == 1){
            ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
            this.filledTbl[r][c] = true;
          }
        }
      }
    }
    else
    {
       //color islands with different colors
      for (let r = 0; r < this.rows ; r++) {
        for (let c = 0; c < this.cols ; c++) {
          if (this.numbTbl[r][c] > 0){
            let num = this.numbTbl[r][c]
            let colorIndex = num % 10 + 1;
            ctx.fillStyle = Color[colorIndex];
            ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
          }
        }
      }
    }
  }

  //count islands number
  countIslands(): number {
    let index: number = 0;
    let cnt: number = 0;

    let cols = this.service.colsCnt;
    let rows = this.service.rowsCnt;

    const check = (r,c) => {
      if (r < 0 || c < 0 || c >= cols || r >= rows ||
        !this.filledTbl[r][c])
          return;

      this.filledTbl[r][c] = false;
      this.numbTbl[r][c] = index;

      check(r + 1, c);
      check(r - 1, c);
      check(r, c + 1);
      check(r, c - 1);

      check(r + 1, c + 1);
      check(r - 1, c  - 1);
      check(r - 1, c + 1);
      check(r + 1, c - 1);
    }

    for (let r = 0; r < rows ; r++) {
      for (let c = 0; c < cols ; c++) {
        if (this.filledTbl[r][c]) {
          cnt++;
          index++;
          check(r,c);
        }
      }
    }

    return cnt;
  };

}
