
import { Router } from '@angular/router';
import { DataService } from './../../shared/data.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css']
})
export class StartComponent  {
  gridSize: string = "";
  isError: boolean = false;


  constructor(
    private service: DataService,
    private router: Router) { }


  onClick(){

     let splitted:string[] = this.gridSize.split(",");

     //check input format
     if ((splitted.length !== 2) ||
      !Number.isInteger(Number(splitted[0])) ||
      !Number.isInteger(Number(splitted[1])))
     {
      this.isError = true;
     }
     else
     {
      this.service.colsCnt = Number(splitted[0]) ;
      this.service.rowsCnt = Number(splitted[1]) ;
      this.isError = false;
      //navigate to grid component
     this.router.navigate(['/grid']);
     }


  }

}
