import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StartComponent } from './pages/start/start.component';
import { GridComponent } from './pages/grid/grid.component';
import { RandomcolorModule } from 'angular-randomcolor';

@NgModule({
  declarations: [
    AppComponent,
    StartComponent,
    GridComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RandomcolorModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
